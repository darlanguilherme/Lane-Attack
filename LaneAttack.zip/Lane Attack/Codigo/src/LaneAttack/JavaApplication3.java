
package LaneAttack;

import LaneAttack.TelaPrincipal;


public class JavaApplication3 {

    public static void main(String[] args) throws Throwable {
       TelaPrincipal t = new TelaPrincipal();
//       TelaAtributos t2 = new TelaAtributos();
//       t2.setVisible(true);

    }
}
